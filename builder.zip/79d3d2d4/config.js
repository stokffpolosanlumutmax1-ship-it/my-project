// config.js

module.exports = {
  BOT_NAME: "Web3Apk Bot",
  BOT_VERSION: "4.0.0",
  BOT_TOKEN: process.env.BOT_TOKEN || "8923555148:AAHCVwAxWh8T60mlvDi7PMekiQ4RrpRkx24",
  ADMIN_IDS: (process.env.ADMIN_IDS || "8988366547").split(",").map(Number).filter(Boolean),
  
  // ------- SETUP GITHUB, WAJIB CENTANG SEMUA IZIN TOKEN PAS DIBUAT ──────────────────────────────────────── 
  GITHUB_TOKEN: "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",
  GITHUB_OWNER: "lannstory010-jpg",
  GITHUB_REPO: "Bulid-apk",

  // ─── TELEGRAM CHANNEL & GROUP CONFIG ────────────────────────────────────────
  CHANNEL_USERNAME: process.env.CHANNEL_USERNAME || "https://t.me/+2ff0uGUv9kExYzRl", 
  CHANNEL_USERNAME2: process.env.CHANNEL_USERNAME2 || "https://t.me/skyzor_project",
  CHANNEL_USERNAME3: process.env.CHANNEL_USERNAME3 || "@skyzor_project",
  // ID Channel/Grup cadangan tempat bot otomatis melempar file users.json setiap ada user baru
  OWNER_ID: parseInt(process.env.OWNER_ID || "8988366547"),

  // ─── SYSTEM CONFIG ──────────────────────────────────────────────────────────
  WELCOME_VIDEO: process.env.WELCOME_VIDEO || "https://files.catbox.moe/fi6euy.mp4",
  NEW_USER: process.env.NEW_USER || "https://files.catbox.moe/4pwx6k.jpg",
  TMP_DIR: "./tmp",

  BUILD_TIMEOUT_MS: 30 * 60 * 1000, // 30 menit
  POLL_INTERVAL_MS: 7000,            // poll setiap 7 detik
  WEB2APK_MAINTENANCE: true,
};


