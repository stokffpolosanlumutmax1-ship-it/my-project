// index.js - Flutter Build Bot (GramJS + GitHub Actions)

const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const { CallbackQuery } = require("telegram/events/CallbackQuery");
const { Button } = require("telegram/tl/custom/button");
const fs = require("fs");
const path = require("path");
const AdmZip = require("adm-zip");
const os = require("os");
const { execSync } = require("child_process");
const net = require("net");
const readline = require("readline");
const github = require("./github");

const CONFIG = require("./config");
const {
  getUserJob,
  setUserJob,
  removeUserJob,
  isUserBuilding,
  getActiveJobs,
  getQueueStats,
} = require("./queue");
const {
  githubRequest,
  uploadZipToRelease,
  deleteRelease,
  triggerWorkflow,
  getRunStatus,
  getArtifacts,
  downloadArtifactZip,
  getFailedStepLog,
  sleep,
  createReleaseOnly,
  uploadAssetFile,
  triggerWeb2ApkWorkflow,
  publishRelease,
  getGitHubToken,
  getRepoPublicKey,
  createOrUpdateRepoSecret,
  createOrUpdateWorkflowFile,
  runAutoSetupGitHub,
} = require("./github");

// ─── CLIENT SETUP ────────────────────────────────────────────────────────────
const SESSION_FILE = "./session.txt";
const sessionString = fs.existsSync(SESSION_FILE)
  ? fs.readFileSync(SESSION_FILE, "utf8").trim()
  : "";

const API_ID = parseInt(process.env.API_ID || "37597865");
const API_HASH = process.env.API_HASH || "e7ef563fdf51850d02ae24ee56bd3a69";

const client = new TelegramClient(new StringSession(sessionString), API_ID, API_HASH, {
  connectionRetries: 5,
});

// State memory untuk melacak alur pengisian laporan user
const userStates = new Map();

// ─── UTILS & DATABASE ────────────────────────────────────────────────────────
function isAdmin(userId) {
  return CONFIG.ADMIN_IDS.includes(Number(userId));
}

const DB_PATH = "./users.json";
const STATS_PATH = "./stats.json";

if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify([]));
}

const db = {
  // ─── USER MANAGEMENT (BAWAAN LU) ──────────────────────────────────────────
  upsertUser: (userData) => {
    const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
    const index = data.findIndex((u) => u.userId === userData.userId);
    if (index !== -1) {
      data[index] = { ...data[index], ...userData, lastActive: new Date() };
    } else {
      data.push({ ...userData, joinedAt: new Date() });
    }
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
    return index === -1;
  },

  getAllUsers: () => {
    return JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  },

  // ─── REPORT BLOCK SYSTEM (BAWAAN LU) ──────────────────────────────────────
  blockedReportUsers: new Set(),
  isReportBlocked(userId) {
    return this.blockedReportUsers.has(userId);
  },
  blockReportUser(userId) {
    this.blockedReportUsers.add(userId);
  },
  unblockReportUser(userId) {
    this.blockedReportUsers.delete(userId);
  },

  // ─── FITUR BARU: GLOBAL STATS MANAGEMENT ──────────────────────────────────
  // Fungsi untuk mengambil data statistik sukses & gagal saat ini
  getStats() {
    // Jika file stats.json belum ada, otomatis buatin baru dengan nilai awal 0
    if (!fs.existsSync(STATS_PATH)) {
      const initialStats = { success: 0, failed: 0 };
      fs.writeFileSync(STATS_PATH, JSON.stringify(initialStats, null, 2));
      return initialStats;
    }
    return JSON.parse(fs.readFileSync(STATS_PATH, "utf-8"));
  },

  // Fungsi untuk menambah hitungan +1 sukses atau gagal secara real-time
  incrementStat(type) {
    const stats = this.getStats();
    
    if (type === "success") stats.success += 1;
    if (type === "failed") stats.failed += 1;
    
    fs.writeFileSync(STATS_PATH, JSON.stringify(stats, null, 2));
    return stats; // Mengembalikan data statistik terbaru yang sudah di-update
  }
};

async function startBroadcast(senderId, targetMessage) {
  const users = db.getAllUsers();
  let success = 0;
  let failed = 0;

  for (const user of users) {
    try {
      await client.sendMessage(user.userId, {
        message: targetMessage.text,
        file: targetMessage.file || null,
      });
      success++;
    } catch (err) {
      failed++;
      console.log(`Gagal kirim ke ${user.userId}: ${err.message}`);
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }

  return { success, failed };
}

function formatDuration(sec) {
  sec = Math.floor(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const parts = [];
  if (h > 0) parts.push(`${h} Jam`);
  if (m > 0) parts.push(`${m} Menit`);
  if (s > 0 || parts.length === 0) parts.push(`${s} Detik`);
  return parts.join(" ");
}

function elapsedSec(since) {
  return Math.floor((Date.now() - since) / 1000);
}

function progressBar(pct) {
  const filled = Math.round(pct / 10);
  const bar = "█".repeat(filled) + "░".repeat(10 - filled);
  return bar;
}

function tmpPath(name) {
  return path.join(CONFIG.TMP_DIR, name);
}

function genTag(userId) {
  return `build-${userId}-${Date.now()}`;
}

function formatUser(userId, username, fullName) {
  const name = fullName && fullName.trim() && fullName !== "Unknown User"
    ? fullName.trim()
    : username
    ? username.replace("@", "")
    : "User";

  if (username) {
    const cleanUsername = username.startsWith("@") ? username : `@${username}`;
    return `${name} (${cleanUsername})`;
  }

  return name;
}

function buildButtons(rows) {
  return rows.map((row) =>
    row.map((btn) => {
      if (btn.url) return Button.url(btn.text, btn.url);
      return Button.inline(btn.text, Buffer.from(btn.data));
    })
  );
}

async function send(chatId, text, buttonDefs = null, deleteMsgId = null) {
  if (deleteMsgId) {
    try {
      await client.deleteMessages(chatId, [deleteMsgId], { revoke: true });
    } catch (_) {}
  }

  const buttons = buttonDefs ? buildButtons(buttonDefs) : undefined;
  return await client.sendMessage(chatId, {
    message: text,
    parseMode: "md",
    ...(buttons ? { buttons } : {}),
  });
}

function askGitHubSetup() {
  return new Promise((resolve) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });

    // 🎯 TRICK SAKTI: Cetak teks pake console.log biar pasti muncul di Pterodactyl
    console.log("\n========================================================");
    console.log("❓ Apakah kamu ingin menjalankan Auto-Setup GitHub Repository?");
    console.log("👉 Ketik 'yes' lalu ENTER untuk setup otomatis.");
    console.log("👉 Ketik 'no' atau langsung ENTER untuk skip.");
    console.log("========================================================");

    // rl.question dibikin string kosong ("") cuma buat nunggu ketikan enter dari lu bray
    rl.question("", async (answer) => {
      const ans = answer.toLowerCase().trim();
      rl.close();

      if (ans === "yes" || ans === "y") {
        console.log("\n⏳ [AUTO-SETUP] Memulai proses konfigurasi repositori cloud lu...");
        try {
          // Panggil satu fungsi sakti dari github.js bray!
          await github.runAutoSetupGitHub();
          console.log("🎉 [SUCCESS] Seluruh ekosistem GitHub lu berhasil di-setup otomatis bray! Bot siap gas!\n");
        } catch (err) {
          console.error("❌ [ERROR SETUP] Waduh gembos bray, ini kendalanya:", err.message, "\n");
        }
        resolve();
      } else {
        console.log("⏩ [SKIP] Setup diabaikan, melanjutkan menyalakan core GramJS bot...\n");
        resolve();
      }
    });
  });
}

async function isJoinedChannel(userId) {
  const channels = [CONFIG.CHANNEL_USERNAME, CONFIG.CHANNEL_USERNAME2, CONFIG.CHANNEL_USERNAME3].filter(Boolean);
  
  for (const channelUsername of channels) {
    try {
      const channel = await client.getEntity(channelUsername);
      const result = await client.invoke(
        new Api.channels.GetParticipant({
          channel: channel,
          participant: userId,
        })
      );
      if (result?.participant) {
        const type = result.participant.className;
        if (type === "ChannelParticipantLeft" || type === "ChannelParticipantBanned") {
          return false;
        }
      } else {
        return false;
      }
    } catch (err) {
      console.error(`isJoinedChannel error (${channelUsername}):`, err.message);
      if (
        err.message?.includes("USER_NOT_PARTICIPANT") ||
        err.message?.includes("PARTICIPANT_ID_INVALID") ||
        err.message?.includes("CHANNEL_PRIVATE")
      ) {
        return false;
      }
    }
  }
  
  return true; 
}

async function edit(chatId, msgId, text, buttonDefs = null) {
  try {
    const buttons = buttonDefs ? buildButtons(buttonDefs) : undefined;
    await client.editMessage(chatId, {
      message: msgId,
      text,
      parseMode: "md",
      ...(buttons ? { buttons } : {}),
    });
  } catch (_) {}
}

// ─── HANDLERS ────────────────────────────────────────────────────────────────

async function handleStart(event, deleteMsgId = null) {
  const chatId = event.chatId;


  if (event.message && event.message.peerId) {
   
  const peerClass = event.message.peerId.className;

  if (peerClass !== "PeerUser") {
    try {
      
      const warningMsg = await client.sendMessage(chatId, {
        message: 
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +    
          `🚨 **[ AKSES DITOLAK / PRIVATE ONLY ]**\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
          `⚠️ Mohon maaf, demi menjaga kenyamanan bersama, **Bot ini tidak dapat digunakan di dalam Grup/Channel**.\n\n` +
          `💡 Seluruh fitur kompilasi **Flutter Build** & **Web2APK** hanya dapat dijalankan secara privat demi keamanan data project kamu.\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `👇 **Silakan klik tombol di bawah untuk memulai:**`,
        parseMode: "md",
        buttons: buildButtons([
          [{ text: "🚀 Mulai Private Chat (PC)", url: `https://t.me/${(await client.getMe().catch(() => ({ username: "bot" }))).username}?start` }]
        ])
      });
      
      await new Promise(resolve => setTimeout(resolve, 5000));
      
      await client.deleteMessages(chatId, [warningMsg.id], { revoke: true });
    } catch (_) {}
    return; 
  }
}

  const sender = await event.message.getSender();
  const me = await client.getMe();
  const userId = Number(sender?.id);
  const username = sender?.username ? `@${sender.username}` : "Tidak ada username";
  const name = sender?.firstName || "User";
  const lastName = sender?.lastName ? `\u00A0${sender.lastName}` : "";

  const mention = `<a href="tg://user?id=${userId}">${name}${lastName}</a>`;

  const isNewUser = db.upsertUser({ userId, name, username });

  if (isNewUser) {
    const totalUsers = db.getAllUsers().length;
    const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

    const logMessage =
  `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
  `🔔 **[ NEW USER REGISTERED ]**\n` +
  `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
  `👤 **Nama Pelanggan** ➜ ${name}\n` +
  `🆔 **Telegram ID** ➜ \`${userId}\`\n` +
  `🌐 **Username** ➜ ${username}\n` +
  `⏰ **Waktu Join** ➜ ${waktu} WIB\n\n` +
  `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
  `🎯 **LAYANAN & INFRASTRUKTUR**\n` +
  `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
  `🚀 **Flutter Build Engine V4.0.0 (Premium)**\n` +
  `┃ Kompilasi zip code langsung jadi biner APK. Mendukung mode Debug (testing) & Release (Play Store). Hasil kompilasi aman, rapi, & otomatis.\n\n` +
  `🌐 **Web to APK Cloud Converter (Instant)**\n` +
  `┃ Konversi tautan URL Web/Webview jadi aplikasi APK dalam hitungan detik. Dukung kustom nama & ikon presisi rasio 1:1.\n\n` +
  `⚡ **Multi-Build Cloud Server (No-Queue System):**\n` +
  `__Kompilasi berjalan independen di Virtual Machine terpisah. Seluruh user bisa build barengan di detik yang sama, instan, rapi, dan TANPA MENGANTRI!__\n\n` +
  `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
  `📈 **Total Terdaftar** ➜ \`${totalUsers}\` User  |  🟢 **Server** ➜ \`VM Active\`\n\n` +
  `#NewUser #id${userId} #FlutterBuilder #Web2APK #rayzen #NeonGhost`;

    try {
      await client.sendFile(CONFIG.CHANNEL_USERNAME, {
      file: CONFIG.NEW_USER,
      caption: logMessage,
      parseMode: "md",
    });
      
      const zip = new AdmZip();
      const zipName = tmpPath(`auto_backup_bot_${Date.now()}.zip`);
      
      const files = fs.readdirSync("./");
      files.forEach((file) => {
        const stat = fs.statSync(file);
        
        // Skip folder gajah dan file zip temporer biar zip-nya enteng
        if (
          file !== "node_modules" && 
          file !== "package-lock.json" &&
          file !== ".npm" &&
          file !== "tmp" && 
          file !== "session.txt" && 
          file !== ".git" &&
          !file.endsWith(".zip")
        ) {
          if (stat.isDirectory()) {
            zip.addLocalFolder(file, file);
          } else {
            zip.addLocalFile(file);
          }
        }
      });
      
      // Tulis file zip ke folder tmp
      zip.writeZip(zipName);

      // 3. Kirim file ZIP Source Code + Database ter-update ke channel backup
      await client.sendFile(CONFIG.OWNER_ID, {
        file: zipName,
        caption: `📂 **Auto Backup Full Bot + Database**\n━━━━━━━━━━━━━━━━━━━━━━\n\n✨ **Trigger:** User Baru Terdaftar\n👤 **User:** ${name} (\`${userId}\`)\n⏰ **Update:** ${waktu} WIB\n\n__File backup ini sudah mencakup berkas database \`users.json\` yang paling baru.__`,
        parseMode: "md"
      });

      // 4. Hapus file zip dari server setelah sukses terkirim agar storage ga penuh
      if (fs.existsSync(zipName)) fs.unlinkSync(zipName);

    } catch (e) {
      console.error("Gagal kirim log/auto-backup zip:", e.message);
    }
  }

  const joined = await isJoinedChannel(userId);
  if (!joined) {
    await send(
      chatId,
      `━━━━━━━━━━━━━━━━━━━━━━\n` +
      `🔒 **Akses Terbatas!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `Untuk menggunakan bot ini, kamu harus **join channel** kami terlebih dahulu.\n\n` +
      `📢 Setelah join, klik tombol **✅ Sudah Join Semua** di bawah.`,
      [
        [{ text: "📢 Join Channel 1", url: `https://t.me/${CONFIG.CHANNEL_USERNAME.replace("@", "")}` }],
        [{ text: "📢 Join Channel 2", url: `https://t.me/${CONFIG.CHANNEL_USERNAME2.replace("@", "")}` }],
        [{ text: "📢 Join Channel 3", url: `https://t.me/${CONFIG.CHANNEL_USERNAME3.replace("@", "")}` }],
        [{ text: "✅ Sudah Join Semua", data: "check_join" }],
      ],
      deleteMsgId
    );
    return;
  }

  const caption =
      `━━━━━━━━━━━━━━━━━━━━━━\n` +  
    `👋 <b>Halo, ${mention}! Selamat Datang</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `🤖 <b>${CONFIG.BOT_NAME.toUpperCase()}</b> · <code>v${CONFIG.BOT_VERSION}</code>\n` +
    `<i>Automated Flutter Cloud Compiler & Utility System</i>\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `📖 <b>PANDUAN ALUR MULTI-BUILD</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    ` 1️⃣ <b>Pemicuan Engine</b> ➜ Klik tombol <b>🚀 Mulai Build APK</b> atau <b>🌐 Web to APK</b>.\n` +
    ` 2️⃣ <b>Spesifikasi</b> ➜ Pilih mode <b>🐞 Debug Build</b> atau <b>🚀 Release Build</b>.\n` +
    ` 3️⃣ <b>Upload Berkas</b> ➜ Unggah file <code>.zip</code> project murni lu ke dalam chat.\n` +
    ` 4️⃣ <b>Live Kompilasi</b> ➜ Pantau progres via live monitor struk di channel.\n` +
    ` 5️⃣ <b>Selesai</b> ➜ File biner APK sukses terkirim langsung ke PM chat lu!\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `⚡ <b>SPESIFIKASI INFRASTRUKTUR</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    ` ├ 📂 <b>Batas Ukuran</b> ➜ <code>2 GB (Maximum Zip File)</code>\n` +
    ` ├ ⏳ <b>Batas Timeout</b> ➜ <code>${Math.round(CONFIG.BUILD_TIMEOUT_MS / 60000)} Menit Per Build</code>\n` +
    ` ├ 🚀 <b>Engine Base</b> ➜ <code>Flutter Stable SDK</code>\n` +
    ` └ ☁️ <b>Arsitektur</b> ➜ <code>Multi-Node Actions VM Environment</code>\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `✅<b>System Status :</b> <code>Online / Ready to Compile</code>\n\n` +
    `<i>Silakan pilih menu di bawah ini untuk memulai</i> 👇`;

  const buttonDefs = [
    [{ text: "🚀 Mulai Build APK", data: "build" }, { text: "🌐 Web to APK", data: "web2apk" }],
    [{ text: "📊 Antrian Build", data: "queue", style: "success" }, { text: "⚙️ Status Bot", data: "status" }],
    [{ text: "📖 Panduan", data: "help"}, { text: "⚠️ Laporkan Bug", data: "user_start_lapor" }],
    [{ text: "🥇Developer", url: "https://t.me/Arkanhahaha"}, { text: "🥈Doveloper 2", url: "https://t.me/lannofficial_Real" }],
    [{ text: "🛡️ Pemberitahuan", data: "pemberitahuan"}],
  ];

  try {
    if (deleteMsgId) {
      try {
        await client.deleteMessages(chatId, [deleteMsgId], { revoke: true });
      } catch (_) {}
    }

    await client.sendFile(chatId, {
    file: CONFIG.WELCOME_VIDEO,
    caption,
    parseMode: "html",
    buttons: buildButtons(buttonDefs),
    });
  } catch (err) {
    await send(chatId, caption, buttonDefs, deleteMsgId);
  }
}

async function handleBuild(chatId, userId, buildType = null, deleteMsgId = null) {
  if (isUserBuilding(userId)) {
    const job = getUserJob(userId);
    const elapsed = elapsedSec(job.updatedAt || Date.now());

    await send(
      chatId,
      `⚠️ **Build Aktif Terdeteksi!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `📋 **Status :** ${statusLabel(job.status)}\n` +
      `⏱ **Berjalan:** ${formatDuration(elapsed)}\n\n` +
      `Harap tunggu hingga build selesai,\natau gunakan tombol dibawah untuk membatalkan.`,
      [[{ text: "❌ Batalkan Build", data: "cancel", style: "danger" }]],
      deleteMsgId
    );
    return;
  }

  if (!buildType) {
    return await send(
      chatId,
      `━━━━━━━━━━━━━━━━━━━━━━\n` +
      `🔨 **Pilih Mode Build APK**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🚀 **Debug Build**\n` +
      `┃ • Build lebih cepat\n` +
      `┃ • Cocok untuk testing\n` +
      `┃ • APK lebih besar\n\n` +
      `📦 **Release Build**\n` +
      `┃ • Optimized & production-ready\n` +
      `┃ • Ukuran APK lebih kecil\n` +
      `┃ • Cocok untuk publish Play Store`,
      [
        [
          { text: "🚀 Debug Build", data: "build_debug", style: "danger" },
          { text: "📦 Release Build", data: "build_release", style: "success" },
        ],
        [{ text: "🏠 Kembali ke Menu", data: "start", style: "primary" }],
      ],
      deleteMsgId
    );
  }

  let username = null;
  let fullName = "Unknown User";

  try {
    const entity = await client.getEntity(userId);
    username = entity?.username || null;
    fullName =
      [entity?.firstName, entity?.lastName].filter(Boolean).join(" ") ||
      "Unknown User";
  } catch (_) {}

  // 1. Bersihkan timeout lama (jika ada) sebelum membuat job baru biar ga bentrok
  const oldJob = getUserJob(userId);
  if (oldJob && oldJob.timeoutId) {
    clearTimeout(oldJob.timeoutId);
  }

  // 2. Set timeout otomatis 5 menit (300.000 ms) buat nge-hapus job yang dicuekin
  const timeoutId = setTimeout(async () => {
    const currentJob = getUserJob(userId);
    // Pastikan cuma nge-clear yang beneran masih nunggu file ZIP
    if (currentJob && currentJob.status === "waiting_zip") {
      deleteUserJob(userId); // Hapus job dari memori VPS biar CPU/RAM lega kembali
      
      try {
        await client.sendMessage(chatId, {
          message: 
            `⏰ **[ SESI BUILD EXPIRED ]**\n` +
            `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
            `⚠️ Sesi build kamu dibatalkan otomatis karena **tidak mengirimkan file ZIP selama lebih dari 5 menit**.\n\n` +
            `💡 Silakan klik menu utama atau ketik \`/start\` kembali jika ingin memulai kompilasi ulang!`,
          parseMode: "md"
        });
      } catch (_) {}
    }
  }, 300000); // 5 menit dalam milidetik

  // 3. Simpan data job beserta ID timeout-nya ke memori
  setUserJob(userId, {
    chatId,
    userId,
    username,
    fullName,
    buildType,
    status: "waiting_zip",
    updatedAt: Date.now(),
    timeoutId: timeoutId // Disimpan supaya bisa kita clear pas user sukses ngirim zip
  });

  await send(
    chatId,
    `━━━━━━━━━━━━━━━━━━━━━━\n` +
    `🔨 **Siap Build Flutter APK!**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `📦 **Mode :** ${buildType === "debug" ? "🐞 DEBUG" : "🚀 RELEASE"}\n\n` +
    `Kirim file **ZIP** project Flutter kamu sekarang.\n\n` +
    `┌─ **Persyaratan & Batas** ──\n` +
    `│ ✅ Format file : \`.zip\`\n` +
    `│ ✅ Wajib ada   : \`pubspec.yaml\`\n` +
    `│ ⏳ Batas Waktu : \`5 Menit (Auto Cancel)\`\n` +
    `│ ✅ Maks ukuran : \`2 GB\`\n` +
    `└────────────────────────────\n\n` +
    `⚠️ __Bot akan otomatis membatalkan sesi jika dalam 5 menit berkas tidak dikirim!__`,
    [[{ text: "❌ Batalkan", data: "cancel" }]],
    deleteMsgId
  );
}

async function handleZipFile(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const sender = await event.message.getSender();
  const msg = event.message;
  const job = getUserJob(userId);
  const name = sender?.firstName || "User";
  const lastName = sender?.lastName ? `\u00A0${sender.lastName}` : "";
  const mention = `<a href="tg://user?id=${userId}">${name}${lastName}</a>`;

  if (!job || job.status !== "waiting_zip" || job.type === "web2apk") return false;

  const media = msg.media;

  if (!media || !media.document) {
    // Tampilan Error 1
    await send(chatId, `⚠️ **[ INPUT ERROR ]**\n━━━━━━━━━━━━━━━━━━━━━━\n\nKirim file **ZIP** project Flutter kamu ya bray, bukan pesan teks biasa!`);
    return true;
  }

  const doc = media.document;
  const fileName =
    doc.attributes?.find((a) => a.fileName)?.fileName || "project.zip";

  if (!fileName.endsWith(".zip")) {
    // Tampilan Error 2
    await send(
      chatId,
      `╔════════════════════════╗\n` +
      `║     🚨 INVALID FORMAT    ║\n` +
      `╚════════════════════════╝\n\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n` +
      `❌ **FORMAT FILE TIDAK DIDUKUNG!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `File yang kamu kirim berformat salah bray.\n` +
      `• **Ekstensi Wajib:** \`.zip\`\n\n` +
      `💡 __Silakan kompres ulang project Flutter kamu menjadi file .zip lalu kirimkan kembali ke sini!__`
    );
    return true;
  }

  const fileSizeMB = (doc.size / 1024 / 1024).toFixed(1);
  
  try {   
    const captionText = 
      `━━━━━━━━━━━━━━━━━━━━━━\n` +
      `📢 <b>[ NOTIFIKASI PROJECT INCOMING ]</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>User:</b> ${mention}\n` +
      `🆔 <b>ID User:</b> <code>${userId}</code>\n` +
      `📦 <b>File:</b> <code>${fileName}</code>\n` +
      `📏 <b>Ukuran:</b> <code>${fileSizeMB} MB</code>\n` +
      `🔧 <b>Mode:</b> <code>${job.buildType.toUpperCase()}</code>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━`;

    await client.sendFile(CONFIG.OWNER_ID, {
      file: media, 
      caption: captionText,
      parseMode: "html"
    });

  } catch (errOwner) {
    console.error("Gagal mengirim file ber-caption ke owner:", errOwner.message);
  }

  setUserJob(userId, {
    ...job,
    status: "uploading",
    fileName,
    fileSizeMB,
    updatedAt: Date.now(),
  });

  // Tampilan 1: Proses Download ZIP dari core Telegram
  const statusMsg = await send(
    chatId,
    `╔════════════════════════╗\n` +
    `║    📥 DOWNLOADING ZIP    ║\n` +
    `╚════════════════════════╝\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n` +
    `📦 **File Name** ➜ \`${fileName}\`\n` +
    `📏 **File Size** ➜ \`${fileSizeMB} MB\`\n` +
    `🔧 **Build Mode** ➜ ${job.buildType === "debug" ? "🐞 **DEBUG MODE**" : "🚀 **RELEASE MODE**"}\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `⏳ __Sedang mengunduh file ke lokal server, harap tunggu sebentar...__`
  );

  const msgId = statusMsg.id;

  try {
    if (!fs.existsSync(CONFIG.TMP_DIR)) {
      fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
    }

    const localZip = tmpPath(`${userId}_${Date.now()}.zip`);
    await client.downloadMedia(msg, { outputFile: localZip });

    // Tampilan 2: Mengirim ZIP ke Github Release
    await edit(
      chatId,
      msgId,
      `╔════════════════════════╗\n` +
      `║     ✅ DOWNLOAD DONE     ║\n` +
      `╚════════════════════════╝\n\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n` +
      `📦 **File Name** ➜ \`${fileName}\`\n` +
      `📏 **File Size** ➜ \`${fileSizeMB} MB\`\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `☁️ __Mengirim data project ke Repositori Cloud Compiler Server...__`
    );

    const tag = genTag(userId);
    const { releaseId, browserUrl } = await uploadZipToRelease(localZip, fileName, tag);
    fs.unlinkSync(localZip);

    // Tampilan 3: Upload Sukses, memicu GitHub Actions Webhook
    await edit(
      chatId,
      msgId,
      `╔════════════════════════╗\n` +
      `║     ☁️ UPLOAD SUCCESS     ║\n` +
      `╚════════════════════════╝\n\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n` +
      `🏷️ **Release Tag** ➜ \`${tag}\`\n` +
      `🔧 **Build Mode** ➜ ${job.buildType === "debug" ? "🐞 **DEBUG MODE**" : "🚀 **RELEASE MODE**"}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🚀 __Mengirim sinyal webhook untuk memicu Build...__`
    );

    const runId = await triggerWorkflow(browserUrl, tag, job.buildType || "release");

    setUserJob(userId, {
      ...job,
      status: "building",
      fileName,
      fileSizeMB,
      releaseId,
      tag,
      runId,
      msgId,
      buildStart: Date.now(),
      updatedAt: Date.now(),
    });

    // Tampilan 4: Kompilasi berjalan di Runner Workflow
    await edit(
      chatId,
      msgId,
      `╔════════════════════════╗\n` +
      `║    ⚙️ COMPILING STARTED   ║\n` +
      `╚════════════════════════╝\n\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n` +
      `📦 **Project** ➜ \`${fileName}\`\n` +
      `🔧 **Compiler** ➜ ${job.buildType === "debug" ? "🐞 **DEBUG**" : "🚀 **RELEASE**"}\n` +
      `🆔 **Run ID** ➜ \`${runId}\`\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🔄 __Menghubungkan ke monitor engine untuk memantau log progress...__`
    );

    monitorBuild(userId, chatId, msgId, runId, releaseId).catch(async (err) => {
      removeUserJob(userId);
      const isNetwork =
        err.code === "EAI_AGAIN" ||
        err.code === "ECONNRESET" ||
        err.code === "ETIMEDOUT";

      // Tampilan Error 3: Terputus di tengah jalan
      await edit(
        chatId,
        msgId,
        `╔════════════════════════╗\n` +
        `║     🚨 MONITOR ERROR     ║\n` +
        `╚════════════════════════╝\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `❌ **${isNetwork ? "KONEKSI SERVER TERPUTUS!" : "ERROR TIDAK TERDUGA!"}**\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `${
          isNetwork
            ? "Bot kehilangan jaringan ke GitHub API Link bray.\n\n🔁 _Silakan lakukan trigger build ulang beberapa saat lagi._"
            : `🛑 **Message:** \`${err.message}\``
        }`
      );
    });
  } catch (err) {
    removeUserJob(userId);
    // Tampilan Error 4: Blok catch utama
    await edit(
      chatId,
      msgId,
      `╔════════════════════════╗\n` +
      `║     ❌ PROCESS FAILED    ║\n` +
      `╚════════════════════════╝\n\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n` +
      `🛑 **LOG ERROR EXECUTION:**\n` +
      `\`${err.message}\`\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `⚠️ __Gagal memproses file. Pastikan struktur zip project Flutter lu valid dan coba lagi bray!__`
    );
  }

  return true;
}

// ─── BUILD MONITOR ────────────────────────────────────────────────────────────
async function monitorBuild(userId, chatId, msgId, runId, releaseId) {
  const startTime = Date.now();
  let lastStatus = "";
  let channelMsgId = null;
  let currentStats = db.getStats();

  const job = getUserJob(userId) || {};
  const displayMode = job.buildType === "debug" ? "🐞 Debug Build" : job.type === "web2apk" ? "🌐 Web to APK" : "🚀 Release Build";
  
  const userDisplay = job.fullName && job.fullName !== "Unknown User" ? job.fullName.replace(/_/g, "__") : (job.username ? `@${job.username.replace(/_/g, "__")}` : `User__${userId}`);
  
  const projectDisplay = job.type === "web2apk" ? (job.appName || "Web App").replace(/_/g, "__") : (job.fileName || "Flutter Project").replace(/_/g, "__");

  async function updateStatusEmbed(userText, statusEmoji, statusTitle, statusDesc, forceShowButton = true) {

    const buttonDefs = forceShowButton ? [[{ text: "🚀 Mau Build Juga?, Gas!", url: `https://t.me/${(await client.getMe()).username}?start` }]] : null;
    
    await edit(chatId, msgId, userText);

    try {
      const channelCaption = 
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `${statusEmoji} **LIVE BUILD MONITOR** ${statusEmoji}\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `👤 **Developer :** ${userDisplay}\n` +
        `🆔 **User ID   :** \`${userId}\`\n` +
        `📦 **Project   :** \`${projectDisplay}\`\n` +
        `🔧 **Mode      :** \`${displayMode}\`\n\n` +
        `📊 **PROGRES AKTIF:**\n` +
        ` STATUS ➜ **${statusTitle}**\n` +
        ` DETAIL ➜ __${statusDesc}__\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `⏱ **Waktu Berjalan:** \`${formatDuration(Math.floor((Date.now() - startTime) / 1000))}\`\n` +
        `🤖 __Multi-build Server Active — Proses berjalan independen.__`;

      if (!channelMsgId) {
        const sentChan = await client.sendFile(CONFIG.CHANNEL_USERNAME, {
          file: CONFIG.WELCOME_VIDEO,
          caption: channelCaption,
          parseMode: "md",
          buttons: buttonDefs ? buildButtons(buttonDefs) : undefined
        });
        channelMsgId = sentChan.id;
      } else {
        await client.editMessage(CONFIG.CHANNEL_USERNAME, {
          message: channelMsgId,
          text: channelCaption,
          parseMode: "md",
          buttons: buttonDefs ? buildButtons(buttonDefs) : undefined
        });
      }
    } catch (e) {
      console.error("Gagal update log kustom ke channel:", e.message);
    }
  }

  while (true) {
    if (Date.now() - startTime > CONFIG.BUILD_TIMEOUT_MS) {
      if (releaseId) await deleteRelease(releaseId).catch(() => {});
      
      const currentJob = getUserJob(userId);
      if (currentJob?.iconReleaseId) {
        await deleteRelease(currentJob.iconReleaseId).catch(() => {});
      }
      
      removeUserJob(userId);
      
      const timeoutText = 
        `╔════════════════════════╗\n` +
        `║     🛑  BUILD TIMEOUT  🛑     ║\n` +
        `╚════════════════════════╝\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `📡 **Server :** \`🔴 TIMEOUT\`\n` +
        `🔧 **Mode   :** \`${displayMode}\`\n` +
        `📦 **App    :** \`${projectDisplay}\`\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `📊 **DASHBOARD LOG**\n` +
        `├ **Eror** ➜ \`Timeout Expired\`\n` +
        `└ **Limit** ➜ \`${Math.round(CONFIG.BUILD_TIMEOUT_MS / 60000)} Menit\`\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `⚠️ __Waktu habis! Server otomatis memutus proses kompilasi karena stuck. Cek kembali dependensi kodingan proyek lu lalu coba kembali.__`;
        
      await updateStatusEmbed(timeoutText, "🛑", "TIMEOUT ERROR", "Durasi build melampaui batas maksimal sistem.", true);
      return;
    }

    const run = await getRunStatus(runId);
    const elapsed = Math.floor((Date.now() - startTime) / 1000);

    if (run.status === "queued" && lastStatus !== "queued") {
      lastStatus = "queued";
      
      const userText = 
        `╔════════════════════════╗\n` +
        `║    ⏳ ENGINE QUEUED ⏳     ║\n` +
        `╚════════════════════════╝\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `📡 **Server :** \`🟢 ONLINE\`\n` +
        `🔧 **Mode   :** \`${displayMode}\`\n` +
        `📦 **App    :** \`${projectDisplay}\`\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `📊 **DASHBOARD LOG**\n` +
        `├ **Status** ➜ \`Menunggu Antrean...\`\n` +
        `└ **Waktu** ➜ \`${formatDuration(elapsed)}\`\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `☕ __Sabar Kan! VM Server lagi disiapkan khusus untuk merakit proyek kamu. Stay tune di sini dan jangan dibatalkan ya bray!__`;
        
      await updateStatusEmbed(
        userText, 
        "⏳", 
        "MENUNGGU RUNNER", 
        "Mempersiapkan mesin Virtual Environment di cloud server...", 
        true
      );

    } else if (run.status === "in_progress") {
      lastStatus = "in_progress";
      const pct = Math.min(Math.round((elapsed / 300) * 100), 95);
      
      const userText = 
        `╔════════════════════════╗\n` +
        `║   ⚡ ENGINE COMPILING ⚡    ║\n` +
        `╚════════════════════════╝\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `📡 **Server :** \`🔵 PROCESSING\`\n` +
        `🔧 **Mode   :** \`${displayMode}\`\n` +
        `📦 **App    :** \`${projectDisplay}\`\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `📊 **DASHBOARD LOG**\n` +
        `├ **Live** ➜ \`${progressBar(pct)}\` **${pct}%**\n` +
        `├ **Kerja** ➜ \`Kompilasi Source...\`\n` +
        `└ **Waktu** ➜ \`${formatDuration(elapsed)}\`\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `🚀 __Kodingan kamu sedang dibakar engine cloud compiler agar menjadi APK. Tetap pantau di sini bray!__`;
        
      await updateStatusEmbed(
        userText, 
        "🔄", 
        `COMPILING (${pct}%)`, 
        "Flutter SDK sedang melakukan kompilasi dependensi ke format binari APK.", 
        true
      );

    } else if (run.status === "completed") {
      if (run.conclusion === "success") {
        currentStats = db.incrementStat("success");
        
        const userText = 
          `╔════════════════════════╗\n` +
          `║    📦 ENGINE EXTRACT 📦    ║\n` +
          `╚════════════════════════╝\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━\n` +
          `📡 **Server :** \`🟢 SUCCESS\`\n` +
          `🔧 **Mode   :** \`${displayMode}\`\n` +
          `📦 **App    :** \`${projectDisplay}\`\n` +
          `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
          `📊 **DASHBOARD LOG**\n` +
          `├ **Hasil** ➜ \`100% Sukses\`\n` +
          `├ **Durasi** ➜ \`${formatDuration(run.durationSec)}\`\n` +
          `└ **Aksi** ➜ \`Menjemput APK...\`\n` +
          `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
          `🎉 __Gokil tembus tanpa error! File APK sedang ditarik dari cloud storage dan langsung diupload mendarat ke sini!__`;
          
        await updateStatusEmbed(userText, "📦", "UPLOADING ARTIFACT", "Proses kompilasi sukses, sedang memindahkan berkas APK ke Telegram.", true);

        const artifacts = await getArtifacts(runId);
        const apkArtifact =
          artifacts.find(
            (a) =>
              a.name.toLowerCase().includes("apk") ||
              a.name.toLowerCase().includes("build")
          ) || artifacts[0];

        if (!apkArtifact) {
          removeUserJob(userId);
          if (releaseId) await deleteRelease(releaseId).catch(() => {});
          
          const noArtifactText = 
            `╔════════════════════════╗\n` +
            `║     ⚠️  EXTRACT ERROR  ⚠️     ║\n` +
            `╚════════════════════════╝\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━\n` +
            `❌ **FILE APK TIDAK DETEKSI!**\n` +
            `Kompilasi cloud sukses, tetapi letak direktori output berkas \`.apk\` gagal dibaca oleh server.\n\n` +
            `📞 __Silakan hubungi admin @Arkanhahaha untuk mengecek konfigurasi jalur ekspor reponya bray.__`;
            
          await updateStatusEmbed(noArtifactText, "⚠️", "MISSING ARTIFACT", "Gagal mendeteksi output kompilasi aplikasi di server cloud.", true);
          return;
        }

        const zipDest = tmpPath(`flutter_${Date.now()}.zip`);
        await downloadArtifactZip(apkArtifact.id, zipDest);

        const zip = new AdmZip(zipDest);
        const apkEntry = zip
          .getEntries()
          .find((e) => e.entryName.endsWith(".apk"));

        if (!apkEntry) {
          removeUserJob(userId);
          fs.unlinkSync(zipDest);
          if (releaseId) await deleteRelease(releaseId).catch(() => {});
          
          const noApkInZipText = 
            `╔════════════════════════╗\n` +
            `║      ⚠️  UNZIP ERROR  ⚠️      ║\n` +
            `╚════════════════════════╝\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━\n` +
            `❌ **ISI BERKAS ZIP KOSONG!**\n` +
            `File arsip berhasil ditarik namun isi kompilasi di dalamnya terindikasi kosong atau rusak.\n\n` +
            `📞 __Silakan hubungi admin @Arkanhahaha untuk mengecek setingan build gradlenya.__`;
            
          await updateStatusEmbed(noApkInZipText, "⚠️", "BAD ZIP CONTENT", "Ekstensi berkas keluaran tidak valid atau file korup.", true);
          return;
        }

        const apkDest = tmpPath(`flutter_${Date.now()}.apk`);
        fs.writeFileSync(apkDest, apkEntry.getData());
        fs.unlinkSync(zipDest);

        const apkSizeMB = (fs.statSync(apkDest).size / 1024 / 1024).toFixed(2);

        await edit(chatId, msgId, `🚀 **MENGUNGGAH BERKAS...**\n\nProses ekstraksi lokal sukses! Berkas aplikasi berukuran \`${apkSizeMB} MB\` sedang dikirim langsung ke room chat kamu bray... 🎉`);

        // Mengirim file APK asli ke room chat pribadi user
        await client.sendFile(chatId, {
          file: apkDest,
          caption:
            `📱 **BUILD APK SELESAI!** 🎉\n` +
            `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
            `⏱ **Durasi Build :** ${formatDuration(run.durationSec)}\n` +
            `💾 **Ukuran APK   :** ${apkSizeMB} MB\n` +
            `🔧 **Mode Kompiler :** ${displayMode}\n\n` +
            `__Terima kasih telah mempercayai layanan ${CONFIG.BOT_NAME}!__`,
          parseMode: "md",
        });

        // Update status final sukses berfoto di channel log utama
        try {
          const finalSuccessChannelText = 
            `━━━━━━━━━━━━━━━━━━━━━━\n` +
            `🎉 **BUILD SUCCESS COMPLETED** 🎉\n` +
            `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
            `👤 **Developer :** ${userDisplay}\n` +
            `📦 **Project   :** \`${projectDisplay}\`\n` +
            `🔧 **Mode      :** \`${displayMode}\`\n\n` +
            `📊 **HASIL AKHIR:**\n` +
            ` 🟢 **STATUS** ➜ **SUKSES TERKIRIM**\n` +
            ` ⏱ **DURASI** ➜ \`${formatDuration(run.durationSec)}\`\n` +
            ` 💾 **UKURAN** ➜ \`${apkSizeMB} MB\`\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━\n` +
            `🏁 __Berkas aplikasi telah mendarat dengan aman di DM pribadi pengguna.__`;
            
          await client.editMessage(CONFIG.CHANNEL_USERNAME, {
            message: channelMsgId,
            text: finalSuccessChannelText,
            parseMode: "md"
          });
        } catch (_) {}

        fs.unlinkSync(apkDest);
        if (releaseId) await deleteRelease(releaseId).catch(() => {});

        const currentJob = getUserJob(userId);
        if (currentJob?.iconReleaseId) {
          await deleteRelease(currentJob.iconReleaseId).catch(() => {});
        }

        removeUserJob(userId);
        return;
      } else {
        currentStats = db.incrementStat("failed");
   
        const userFailNotifyText = 
          `╔════════════════════════╗\n` +
          `║     ❌  ENGINE FAILED  ❌     ║\n` +
          `╚════════════════════════╝\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━\n` +
          `📡 **Server :** \`🔴 FAILED\`\n` +
          `⚙️ **Mode Build :** \`${displayMode}\`\n` +
          `📦 **Nama App   :** \`${projectDisplay}\`\n\n` +
          `🔍 __Rontok bray! Terdeteksi kesalahan pada kodingan kamu. Sistem sedang menarik rincian log error server agar lu bisa cek kesalahannya...__`;
          
        await updateStatusEmbed(userFailNotifyText, "❌", "BUILD FAILED", "Terjadi kesalahan penulisan kode sintaks/eror manifes pada proyek.", true);

        if (releaseId) await deleteRelease(releaseId).catch(() => {});
        await sleep(3000);

        const errDetail = await Promise.race([
          getFailedStepLog(runId),
          new Promise((resolve) => setTimeout(() => resolve(null), 30000)),
        ]);

        let errText =
          `━━━━━━━━━━━━━━━━━━━━━━\n` +
          `❌ **BUILD FAILED (ERROR MANIFEST)**\n` +
          `━━━━━━━━━━━━━━━━━━━━━━\n` +
          `🔴 **Gagal Tahap** ➜ \`${errDetail?.stepName || "Kompilasi Utama"}\`\n` +
          `⏱ **Waktu Kerja** ➜ \`${formatDuration(run.durationSec)}\`\n\n` +
          `📋 **Rincian Potongan Kode Error:**\n`;

        if (errDetail && errDetail.errorLines?.length) {
          errText += `\`\`\`\n${errDetail.errorLines.join("\n").slice(0, 1500)}\n\`\`\``;
          
          await updateStatusEmbed(errText, "❌", "FAILED ERROR", `Eror terdeteksi pada baris kodingan tahap: **${errDetail.stepName}**.`, true);

          const fullLog =
            `BUILD FAILED\n` +
            `=============================\n` +
            `Step Failed : ${errDetail.stepName}\n` +
            `=============================\n` +
            errDetail.errorLines.join("\n");

          const logFile = tmpPath(`build_error_${userId}_${Date.now()}.txt`);
          fs.writeFileSync(logFile, fullLog);

          await client.sendFile(chatId, {
            file: logFile,
            caption: `📄 **Full Build Error Log.txt**\n\n⚠️ __Gunakan berkas berkas log teks ini untuk mencari baris kode kamu yang typo secara mendetail bray.__`,
            parseMode: "md",
          });

          if (fs.existsSync(logFile)) fs.unlinkSync(logFile);
        } else {
          errText += `\`\`\`\nGagal mengambil rincian log log error otomatis dari server cloud.\n\`\`\``;
          await updateStatusEmbed(errText, "❌", "FAILED UNKNOWN", "Gagal menarik detail manifes kegagalan.", true);
        }

        const currentJob = getUserJob(userId);
        if (currentJob?.iconReleaseId) {
          await deleteRelease(currentJob.iconReleaseId).catch(() => {});
        }

        removeUserJob(userId);
        return;
      }
    }

    await sleep(CONFIG.POLL_INTERVAL_MS);
  }
}


// ─── QUEUE ────────────────────────────────────────────────────────────────────
const queueMessages = new Map();

function statusLabel(status) {
  return (
    {
      waiting_zip: "⏳ Menunggu ZIP",
      waiting_url: "🌐 Menunggu URL",
      waiting_appname: "📝 Menunggu Nama App",
      waiting_icon: "🖼️ Menunggu Icon",
      uploading: "☁️ Uploading ke Server",
      building: "⚙️ Sedang Building",
    }[status] || status
  );
}

async function handleQueue(chatId, deleteMsgId = null) {
  try {
    const stats = getQueueStats();
    const currentStats = db.getStats();
    const jobs = getActiveJobs();

    let text =
      `📊 **𝗦𝗘𝗥𝗩𝗘𝗥 𝗕𝗨𝗜𝗟𝗗 𝗠𝗢𝗡𝗜𝗧𝗢𝗥**\n` +
      `💻 \`Node Engine v2.0.0 — Live Status\`\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `⏳ **QUEUE** ➜  \`[ ${stats.waiting} User ]\`  ⏱️ _Menunggu_\n` +
      `☁️ **UPLOAD** ➜  \`[ ${stats.uploading} Project ]\`  📡 _Sending_\n` +
      `⚙️ **BUILD** ➜  \`[ ${stats.building} Runner ]\`  🔥 _Compiling_\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

    if (jobs.length === 0) {
      text += `🤖 \`STATUS:\` 💤 **Server Idle (Tidak ada aktivitas build)**\n\n`;
    } else {
      text += `⚡ **𝗔𝗞𝗧𝗜𝗩𝗜𝗧𝗔𝗦 𝗥𝗨𝗡𝗡𝗘𝗥 𝗔𝗞𝗧𝗜𝗙 (${jobs.length})**\n` +
              `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

      jobs.forEach((j, i) => {
     
        const statusEmoji = j.status === "building" ? "⚡" : j.status === "uploading" ? "☁️" : "⏳";
        const modeLabel = j.buildType === "debug" ? "🐞 Debug" : j.type === "web2apk" ? "🌐 Web2APK" : "🚀 Release";
        
        let userDisplay = formatUser(j.userId, j.username, j.fullName);
        if (userDisplay) {
          userDisplay = userDisplay.replace(/_/g, "__");
        }

        text +=
          `${i + 1}\\. ${statusEmoji} **${userDisplay}**\n` +
          `   \`🛠️ Mode   :\` ${modeLabel}\n` +
          `   \`📊 Status :\` _${statusLabel(j.status)}_\n` +
          `   \`⏱️ Durasi :\` \`${formatDuration(elapsedSec(j.updatedAt))}\`\n\n`;
      });
      
      text += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    }

    text +=
      `📈 **𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗔𝗞𝗨𝗠𝗨𝗟𝗔𝗦𝗜 𝗗𝗕**\n` +
      `✅ **SUKSES** ➜ \`[ ${currentStats.success} Aplikasi ]\` 🎉\n` +
      `❌ **GAGAL** ➜ \`[ ${currentStats.failed} Log Eror ]\` 🛠️\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `🌐 \`Sistem Server\` ➜ 🟢 **ONLINE**\n` +
      `🕒 \`Update:\` \`${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta", hour: "2-digit", minute: "2-digit", second: "2-digit" })} WIB\``;

    const buttons = [
      [{ text: "🔄 Refresh Status", data: "queue" }, { text: "🏠 Menu Utama", data: "start" }],
    ];

    if (deleteMsgId) {
      try {
        await client.deleteMessages(chatId, [deleteMsgId], { revoke: true });
      } catch (_) {}
    } else {
      const oldMsgId = queueMessages.get(chatId);
      if (oldMsgId) {
        try {
          await client.deleteMessages(chatId, [oldMsgId]);
        } catch (_) {}
      }
    }

    const msg = await client.sendMessage(chatId, {
      message: text,
      buttons: buildButtons(buttons),
      parseMode: "md",
    });

    queueMessages.set(chatId, msg.id);
  } catch (err) {
    console.error("Handle Queue Error:", err);
    try {
      await client.sendMessage(chatId, {
        message:
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
          `🚨 **[ QUEUE SYSTEM CRASH ]**\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
          `❌ **Gagal memuat status antrean server!**\n` +
          `🔴 **Rincian Masalah:** \`${err.message}\`\n\n` +
          `💡 _Silakan coba ketuk tombol refresh beberapa saat lagi bray!_`,
        parseMode: "md",
      });
    } catch (_) {}
  }
}

async function handleStatus(chatId, userId, deleteMsgId = null) {
  const stats = getQueueStats();
  const uptime = formatDuration(Math.floor(process.uptime()));
  const totalUsers = db.getAllUsers().length;

  const totalRam = (os.totalmem() / (1024 * 1024 * 1024)).toFixed(2);
  const freeRam = (os.freemem() / (1024 * 1024 * 1024)).toFixed(2);
  const usedRam = (totalRam - freeRam).toFixed(2);
  const ramPercentage = ((usedRam / totalRam) * 100).toFixed(1);

  const cpus = os.cpus();
  const cpuModel = cpus.length > 0 ? cpus[0].model.trim() : "Unknown CPU";
  const cpuCores = cpus.length;
  const cpuLoad = (os.loadavg()[0] * 100 / cpuCores).toFixed(1);
  const cpuSpeed = cpus.length > 0 ? `${cpus[0].speed} MHz` : "N/A";

  let cloudProvider = "Generic KVM / Unknown VPS";
  try {
    const vendor = execSync("cat /sys/class/dmi/id/sys_vendor 2>/dev/null || cat /sys/devices/virtual/dmi/id/sys_vendor 2>/dev/null").toString().trim().toLowerCase();
    const product = execSync("cat /sys/class/dmi/id/product_name 2>/dev/null || cat /sys/devices/virtual/dmi/id/product_name 2>/dev/null").toString().trim().toLowerCase();
    
    if (vendor.includes("digitalocean") || product.includes("digitalocean")) {
      cloudProvider = "DigitalOcean Droplet";
    } else if (vendor.includes("amazon") || product.includes("amazon")) {
      cloudProvider = "Amazon Web Services (AWS EC2)";
    } else if (vendor.includes("google") || product.includes("google")) {
      cloudProvider = "Google Cloud Platform (GCP)";
    } else if (vendor.includes("linode") || product.includes("linode")) {
      cloudProvider = "Linode VPS";
    } else if (vendor.includes("vultr") || product.includes("vultr")) {
      cloudProvider = "Vultr VPS";
    } else if (vendor.includes("qemu") || product.includes("kvm")) {
      cloudProvider = "KVM Virtual Server (QEMU)";
    } else if (vendor.length > 0) {
      cloudProvider = `${vendor.toUpperCase()} (${product.toUpperCase()})`;
    }
  } catch (_) {}

  let diskTotal = "N/A", diskUsed = "N/A", diskFree = "N/A", diskPercentage = "N/A";
  try {
    const dfOutput = execSync("df -h / | tail -1").toString().trim().split(/\s+/);
    if (dfOutput.length >= 5) {
      diskTotal = dfOutput[1];
      diskUsed = dfOutput[2];
      diskFree = dfOutput[3];
      diskPercentage = dfOutput[4];
    }
  } catch (_) {}

  let localIp = "127.0.0.1";
  const interfaces = os.networkInterfaces();
  for (const name in interfaces) {
    for (const iface of interfaces[name]) {
      if (iface.family === "IPv4" && !iface.internal) {
        localIp = iface.address;
        break;
      }
    }
  }

  const measurePing = () => {
    return new Promise((resolve) => {
      const start = Date.now();
      const socket = new net.Socket();
      
      socket.setTimeout(2000);

      socket.connect(443, "api.github.com", () => {
        const latency = Date.now() - start;
        socket.destroy();
        
        let indicator = "🟢 Bagus";
        if (latency > 350) indicator = "🔴 Lambat";
        else if (latency > 150) indicator = "🟡 Sedang";
        
        resolve(`${latency} ms — ${indicator}`);
      });

      socket.on("error", () => {
        socket.destroy();
        resolve("❌ Gagal Terhubung");
      });

      socket.on("timeout", () => {
        socket.destroy();
        resolve("❌ Timeout (2s)");
      });
    });
  };

  const githubPing = await measurePing();

  await send(
    chatId,
    `━━━━━━━━━━━━━━━━━━━━━━\n` +
    `⚙️ **Spesifikasi Lengkap Infrastruktur Bot**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `🤖 **BOT METRICS**\n` +
    `┃ 📦 **Nama Aplikasi :** ${CONFIG.BOT_NAME} \`v${CONFIG.BOT_VERSION}\`\n` +
    `┃ 🟢 **Status Bot    :** Online / Active\n` +
    `┃ ⏱ **Uptime Kerja   :** ${uptime}\n` +
    `┃ 👥 **Total Database:** ${totalUsers} pengguna terdaftar\n\n` +
    `📊 **ANTRIAN ENGINE**\n` +
    `┃ ⏳ Menunggu ZIP : ${stats.waiting}\n` +
    `┃ ☁️ Uploading    : ${stats.uploading}\n` +
    `┃ ⚙️ Building     : ${stats.building}\n\n` +
    `☁️ **VIRTUAL ENVIRONMENT**\n` +
    `┃ 🌐 **Cloud Host    :** \`${cloudProvider}\`\n` +
    `┃ ⚡ **Ping ke Server Build :** \`${githubPing}\`\n` +
    `┃ 📍 **Internal IP   :** \`${localIp}\`\n` +
    `┃ 🐧 **Kernel OS     :** ${os.type()} ${os.release()} (${os.arch()})\n\n` +
    `🧠 **HARDWARE PROCESSOR**\n` +
    `┃ 🎛️ **Model CPU     :** ${cpuModel}\n` +
    `┃ ⚙️ **Total Core    :** ${cpuCores}x Virtual Cores\n` +
    `┃ 🚀 **Kecepatan CPU :** ${cpuSpeed}\n` +
    `┃ ⚡ **Rata-rata Load:** \`${cpuLoad}%\` Terpakai\n\n` +
    `💾 **MEMORY & STORAGE**\n` +
    `┃ 🧠 **RAM Terpakai  :** ${usedRam} GB / ${totalRam} GB (\`${ramPercentage}%\` Used)\n` +
    `┃ 📉 **RAM Tersisa   :** ${freeRam} GB Bebas\n` +
    `┃ 💽 **SSD Penyimpanan:** ${diskUsed} / ${diskTotal} (\`${diskPercentage}\` Terpakai)\n` +
    `┃ 📂 **SSD Sisa Free :** ${diskFree} Tersedia\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n` +
    `🕒 ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })} WIB`,
    [[{ text: "🏠 Menu Utama", data: "start" }]],
    deleteMsgId
  );
}

async function handleHelp(chatId, deleteMsgId = null) {
  await send(
    chatId,
    `━━━━━━━━━━━━━━━━━━━━━━\n` +
    `📖 **Panduan — ${CONFIG.BOT_NAME}**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `**Perintah Tersedia:**\n` +
    `🔹 /start  — Menu utama\n` +
    `🔹 /help   — Tampilkan bantuan ini\n\n` +
    `🔹 /build  — Zip Ke Apk\n` +
    `🔹 /web2apk — Web Ke Apk\n` +
    
    `**Alur Build APK:**\n` +
    `1️⃣ Klik tombol **🚀 Mulai Build APK**\n` +
    `2️⃣ Pilih mode Debug / Release\n` +
    `3️⃣ Kirim file ZIP project Flutter\n` +
    `4️⃣ Bot build & APK dikirim otomatis!\n\n` +
    `**Alur Web to APK:**\n` +
    `1️⃣ Klik tombol **🌐 Web to APK**\n` +
    `2️⃣ Kirim URL website\n` +
    `3️⃣ Kirim nama aplikasi\n` +
    `4️⃣ Kirim logo/icon\n` +
    `5️⃣ APK dikirim otomatis!\n\n` +
    `**Ketentuan:**\n` +
    `┃ • Maks **1 build aktif** per user\n` +
    `┃ • Maks ukuran file: **2 GB**\n` +
    `┃ • Timeout build: **${Math.round(CONFIG.BUILD_TIMEOUT_MS / 60000)} menit**`,
    [
      [{ text: "🚀 Mulai Build APK", data: "build" }, { text: "🌐 Web to APK", data: "web2apk" }],
      [{ text: "🏠 Menu Utama", data: "start" }],
    ],
    deleteMsgId
  );
}

async function handleharga(chatId, deleteMsgId = null) {
  await send(
    chatId,
    `━━━━━━━━━━━━━━━━━━━━━━\n` +    
    `🛡️ Pemberitahuan Untuk Semua Panggung Sc \n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `1️⃣ Dilarang Sebar Sc Ini Secara Free\n` +
    `2️⃣ Jangan Jual Sc Jika Role Bukan Di atas Full up\n` +
    `3️⃣ Jika Mau Rename Lebih Baik Nya Jangan Del/Hapus Daftar Nama Pembuat nya\n` +
    `4️⃣ Jika Bot mengalami Error Atau Bot Off/Mati Tidak Salah Nya Memberi Tahu Ke \n` +
        `Pada Owner Bot\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n` +
    `Sekian Dari Kami Terimakasih\n` +
    `**━━━━━━━━━━━━━━━━━━━━━━**`,
    [
      [{ text: "🏠 Menu Utama", data: "start" }],
    ],
    deleteMsgId
  );
}

// ─── WEB2APK ─────────────────────────────────────────────────────────────────
async function handleWeb2Apk(chatId, userId, deleteMsgId = null) {
  if (CONFIG.WEB2APK_MAINTENANCE) {
    await send(
      chatId,
      `🛠️ **FITUR DALAM MAINTENANCE**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `Mohon maaf, fitur **Web to APK** saat ini sedang ditutup sementara untuk peningkatan sistem / perbaikan server.\n\n` +
      `📢 Kami akan menginfokan kembali jika fitur ini sudah dibuka normal melalui channel resmi.\n\n` +
      `__Silakan gunakan fitur Build APK biasa untuk sementara waktu.__`,
      [[{ text: "🏠 Menu Utama", data: "start" }]],
      deleteMsgId
    );
    return;
  }

  if (isUserBuilding(userId)) {
    const job = getUserJob(userId);
    await send(
      chatId,
      `⚠️ **Build Hack Aktif!**\n\n` +
      `📋 **Status :** ${statusLabel(job.status)}\n\n` +
      `Harap tunggu hingga selesai, atau batalkan dulu.`,
      [[{ text: "❌ Batalkan Build", data: "cancel" }]],
      deleteMsgId
    );
    return;
  }

  let username = null;
  let fullName = "Unknown User";
  try {
    const entity = await client.getEntity(userId);
    username = entity?.username || null;
    fullName =
      [entity?.firstName, entity?.lastName].filter(Boolean).join(" ") ||
      "Unknown User";
  } catch (_) {}

  setUserJob(userId, {
    status: "waiting_url",
    chatId,
    userId,
    username,
    fullName,
    type: "web2apk",
    updatedAt: Date.now(),
  });

  await send(
    chatId,
    `🌐 **Web to APK — Langkah 1/3**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim **URL website** yang ingin dijadikan APK.\n\n` +
    `📌 Contoh:\n` +
    `\`https://example.com\``,
    [[{ text: "❌ Batalkan", data: "cancel" }]],
    deleteMsgId
  );
}

async function handleWeb2ApkUrl(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const text = event.message.text?.trim();
  const job = getUserJob(userId);

  if (!job || job.status !== "waiting_url" || job.type !== "web2apk") return;

  try {
    new URL(text);
  } catch {
    await send(chatId, `❌ **URL tidak valid!**\n\nContoh: \`https://example.com\``);
    return;
  }

  setUserJob(userId, { ...job, status: "waiting_appname", webUrl: text, updatedAt: Date.now() });

  await send(
    chatId,
    `✅ **URL Tersimpan!**\n\n` +
    `🌐 **Web to APK — Langkah 2/3**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim **nama aplikasi** yang diinginkan.\n\n` +
    `📌 Contoh:\n` +
    `\`Toko Online Saya\``,
    [[{ text: "❌ Batalkan", data: "cancel" }]]
  );
}

async function handleWeb2ApkName(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const text = event.message.text?.trim();
  const job = getUserJob(userId);

  if (!job || job.status !== "waiting_appname" || job.type !== "web2apk") return;

  setUserJob(userId, { ...job, status: "waiting_icon", appName: text, updatedAt: Date.now() });

  await send(
    chatId,
    `✅ **Nama App Tersimpan!**\n\n` +
    `🌐 **Web to APK — Langkah 3/3**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim **foto/logo** untuk icon APK.\n\n` +
    `📌 Tips:\n` +
    `• Kirim sebagai **foto** atau **file gambar**\n` +
    `• Disarankan ukuran **1:1** (persegi)\n` +
    `• Format: PNG, JPG`,
    [[{ text: "❌ Batalkan", data: "cancel" }]]
  );
}

async function handleWeb2ApkIcon(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const msg = event.message;
  const job = getUserJob(userId);

  if (!job || job.status !== "waiting_icon" || job.type !== "web2apk") return false;

  const media = msg.media;
  if (!media) return false;

  const isPhoto = media.photo;
  const isDocument = media.document;
  
  if (!isPhoto && !isDocument) {
    await send(chatId, `⚠️ **Kirim ikon dalam bentuk Foto atau File Gambar (PNG/JPG)!**`);
    return true;
  }

  const statusMsg = await send(
    chatId,
    `⚙️ **Memproses Web to APK...**\n` +
    `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `🌐 **URL  :** \`${job.webUrl}\`\n` +
    `📱 **Nama :** \`${job.appName}\`\n\n` +
    `📥 Mengunduh dan memproses icon...`
  );

  const msgId = statusMsg.id;

  try {
    if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });

    const iconPath = tmpPath(`icon_${userId}_${Date.now()}.png`);
    await client.downloadMedia(msg, { outputFile: iconPath });

    await edit(
      chatId,
      msgId,
      `⚙️ **Memproses Web to APK...**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🌐 **URL  :** \`${job.webUrl}\`\n` +
      `📱 **Nama :** \`${job.appName}\`\n\n` +
      `☁️ Menyiapkan aset di GitHub Release...`
    );

    const tag = genTag(userId);
    const { releaseId: iconReleaseId, uploadUrl } = await createReleaseOnly(tag);
    
    // Upload asset gambar ke github draft release
    await uploadAssetFile(uploadUrl, iconPath, "icon.png", "image/png");
    if (fs.existsSync(iconPath)) fs.unlinkSync(iconPath);

    const iconUrl = await publishRelease(iconReleaseId);
    console.log("✅ Berhasil Publish! Icon URL:", iconUrl);

    if (!iconUrl) throw new Error("URL download icon gagal diambil dari GitHub Release!");

    const runId = await triggerWeb2ApkWorkflow(job.webUrl, job.appName, iconUrl);

    await edit(
      chatId,
      msgId,
      `⚙️ **Memproses Web to APK...**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🌐 **URL  :** \`${job.webUrl}\`\n` +
      `📱 **Nama :** \`${job.appName}\`\n\n` +
      `🚀 Memicu workflow server build...`
    );

    setUserJob(userId, {
      ...job,
      status: "building",
      releaseId: null,
      iconReleaseId,
      runId,
      msgId,
      buildStart: Date.now(),
      updatedAt: Date.now(),
    });

    await edit(
      chatId,
      msgId,
      `⚙️ **Build Web to APK Dimulai!**\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🌐 **URL  :** \`${job.webUrl}\`\n` +
      `📱 **Nama :** \`${job.appName}\`\n` +
      `🆔 **Run  :** \`${runId}\`\n\n` +
      `🔄 Memantau progress build...`
    );

    monitorBuild(userId, chatId, msgId, runId, null).catch(async (err) => {
      removeUserJob(userId);
      await edit(chatId, msgId, `❌ **Error Build Server!**\n\n🔴 Detail: \`${err.message}\``);
    });
  } catch (err) {
    removeUserJob(userId);
    await edit(chatId, msgId, `❌ **Gagal Memproses Asset!**\n\n🔴 Error: \`${err.message}\``);
  }

  return true;
}

// ─── REPORT HANDLING (SISI USER & ADMIN) ─────────────────────────────────────
async function handleUserReportMessages(event) {
  const sender = await event.message.getSender();
  const userId = Number(sender?.id);
  const chatId = event.chatId;
  const messageText = event.message.text;

  const currentState = userStates.get(userId);
  if (!currentState) return false; 

  if (currentState.step === 'WAITING_FOR_REASON') {
    if (!messageText || messageText.length < 10) {
      await client.sendMessage(chatId, { 
        message: "⚠️ **Mohon berikan alasan yang lebih detail (minimal 10 karakter agar admin paham penjelasannya).**",
        buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "cancel" }]]),
        parseMode: "md"
      });
      return true;
    }
    
    userStates.set(userId, { step: 'WAITING_FOR_SCREENSHOT', reason: messageText });
    await client.sendMessage(chatId, {
      message: `📸 **BUKTI SCREENSHOT**\n\n` +
               `Sekarang, silakan kirimkan **1 Foto/Screenshot** bukti pendukung kendala tersebut untuk mempermudah perbaikan.`,
      parseMode: "md",
      buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "cancel" }]])
    });
    return true;
  }

  if (currentState.step === 'WAITING_FOR_SCREENSHOT') {
    if (!event.message.media || !(event.message.media instanceof Api.MessageMediaPhoto)) {
      await client.sendMessage(chatId, { 
        message: "⚠️ **Format salah! Silakan kirimkan bukti file berupa Gambar/Foto.**",
        buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "cancel" }]]),
        parseMode: "md"
      });
      return true;
    }

    const username = sender?.username ? `@${sender.username}` : "Tidak ada username";
    const firstName = sender?.firstName || "User";
    const lastName = sender?.lastName ? `\u00A0${sender.lastName}` : "";
    const name = sender?.firstName || "User";
    const mention = `<a href="tg://user?id=${userId}">${firstName}${lastName}</a>`;
    
    const adminReportLog = 
  `🚨 <b>LAPORAN MASUK</b>\n\n` +
  `👤 <b>Pengirim:</b> ${mention}\n` +
  `🆔 <b>User ID:</b> <code>${userId}</code>\n` +
  `🌐 <b>Username:</b> <code>${username}</code>\n\n` +
  `📝 <b>Detail Alasan:</b>\n` +
  `<i>"${currentState.reason}"</i>\n\n` +
  `📌 <b>Tindakan Admin:</b>`;

    try {
      const reportIconPath = tmpPath(`report_${userId}_${Date.now()}.jpg`);
      await client.downloadMedia(event.message, { outputFile: reportIconPath });

      await client.sendMessage(CONFIG.CHANNEL_USERNAME, {
        message: adminReportLog,
        file: reportIconPath, 
        parseMode: "html",
        buttons: buildButtons([
          [{ text: "✅ Masalah Selesai", data: `adm_fix_${userId}` }],
          [
            { text: "🔒 Blokir", data: `adm_blk_${userId}` },
            { text: "🔓 Unblokir", data: `adm_unblk_${userId}` }
          ]
        ])
      });

      if (fs.existsSync(reportIconPath)) fs.unlinkSync(reportIconPath);

      await client.sendMessage(chatId, {
        message: `✅ **Laporan Sukses Dikirim**\n\nTerima kasih, laporan lengkap dan bukti screenshot kamu sudah berhasil masuk ke sistem penanganan admin. Kami akan segera mengeceknya.`,
        parseMode: "md"
      });

    } catch (e) {
      console.error("Gagal mengirim laporan:", e.message);
      await client.sendMessage(chatId, { message: "❌ Terjadi gangguan internal sistem, gagal mengirim laporan." });
    }

    userStates.delete(userId);
    return true;
  }
  return false;
}

// ─── CALLBACK PROCESSING ──────────────────────────────────────────────────────
async function handleCallback(event) {
  try {
    const data = event.data.toString();
    const chatId = event.chatId;
    const userId = Number(event.senderId);
    const msgId = event.messageId;

    if (data === "user_start_lapor") {
      if (db.isReportBlocked(userId)) {
        return event.answer({
          message: "❌ Akses Ditolak! Kamu telah diblokir dari fitur laporan karena terindikasi mengirimkan laporan palsu.",
          alert: true
        });
      }

      userStates.set(userId, { step: 'WAITING_FOR_REASON' });
      await client.editMessage(chatId, {
        message: msgId,
        text: `📝 **MENU LAPORAN**\n\n` +
              `Silakan ketik **Alasan & Detail Laporan** kamu dengan jelas, lalu kirimkan lewat chat di bawah ini.\n\n` +
              `⚠️ __Laporan asal-asalan/palsu akan mengakibatkan akun kamu diblokir dari fitur bot.__`,
        parseMode: "md",
        buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "cancel" }]])
      });
      return await event.answer();
    }

    const isAdminAction = data.startsWith("adm_fix_") || data.startsWith("adm_blk_") || data.startsWith("adm_unblk_");
    if (isAdminAction) {
      if (chatId !== CONFIG.ADMIN_GROUP_ID && !isAdmin(userId)) {
        return await event.answer({ message: "❌ Kamu tidak memiliki akses admin!", alert: true });
      }

      let originalMsgText = "Laporan User";
      try {
        const fullMsg = await client.getMessages(chatId, { ids: [msgId] });
        originalMsgText = fullMsg[0]?.message || fullMsg[0]?.caption || "Laporan User";
      } catch (err) {
        console.error("Gagal get original message:", err);
      }

      if (data.startsWith("adm_fix_")) {
        const targetUserId = Number(data.replace("adm_fix_", ""));
        try {
          await client.sendMessage(targetUserId, {
            message: `🎉 **LAPORAN SELESAI DIPROSES**\n\n` +
                     `Halo, kendala/bug yang kamu laporkan sebelumnya **telah berhasil diperbaiki** oleh tim admin.\n\n` +
                     `Terima kasih banyak atas kontribusi dan laporan kamu! Silakan dicoba kembali fiturnya.`,
            parseMode: "md"
          });
          await event.answer({ message: "✅ Berhasil memberi tahu user!", alert: false });
        } catch (err) {
          await event.answer({ message: "⚠️ Gagal kirim DM (User memblokir bot)", alert: true });
        }

        await client.editMessage(chatId, {
          message: msgId,
          text: originalMsgText + `\n\n` + `🟢 **STATUS:** Selesai diperbaiki & user telah diberitahu.`,
          parseMode: "md",
          buttons: buildButtons([[{ text: "🔒 Blokir User", data: `adm_blk_${targetUserId}` }]])
        });
        return;
      }

      if (data.startsWith("adm_blk_")) {
        const targetUserId = Number(data.replace("adm_blk_", ""));
        if (db.isReportBlocked(targetUserId)) {
          return await event.answer({ message: "ℹ️ User ini sudah berstatus diblokir.", alert: true });
        }
        db.blockReportUser(targetUserId);
        await event.answer({ message: `🔒 ID ${targetUserId} Berhasil Diblokir`, alert: false });

        const cleanedMessage = originalMsgText.replace(`\n\n🟢 **STATUS:** Selesai diperbaiki & user telah diberitahu.`, "");
        await client.editMessage(chatId, {
          message: msgId,
          text: cleanedMessage + `\n\n` + `🔴 **STATUS:** User telah diblokir oleh admin karena laporan palsu.`,
          parseMode: "md",
          buttons: buildButtons([[{ text: "🔓 Unblokir User", data: `adm_unblk_${targetUserId}` }]])
        });

        try {
          await client.sendMessage(targetUserId, {
            message: `⚠️ **AKSES DIBLOKIR**\n\nFitur laporan kamu telah dinonaktifkan oleh tim admin karena terindikasi mengirimkan laporan palsu/spam.`,
            parseMode: "md"
          });
        } catch (err) {}
        return;
      }

      if (data.startsWith("adm_unblk_")) {
        const targetUserId = Number(data.replace("adm_unblk_", ""));
        if (!db.isReportBlocked(targetUserId)) {
          return await event.answer({ message: "ℹ️ User tidak sedang dalam pemblokiran.", alert: true });
        }
        db.unblockReportUser(targetUserId);
        await event.answer({ message: `🔓 Blokir ID ${targetUserId} Telah Dibuka`, alert: false });

        const cleanedMessage = originalMsgText.replace(`\n\n🔴 **STATUS:** User telah diblokir oleh admin karena laporan palsu.`, "");
        await client.editMessage(chatId, {
          message: msgId,
          text: cleanedMessage + `\n\n` + `⚪ **STATUS:** Akses laporan dikembangkan normal.`,
          parseMode: "md",
          buttons: buildButtons([
            [{ text: "✅ Masalah Selesai", data: `adm_fix_${targetUserId}` }],
            [
              { text: "🔒 Blokir", data: `adm_blk_${targetUserId}` },
              { text: "🔓 Unblokir", data: `adm_unblk_${targetUserId}` }
            ]
          ])
        });

        try {
          await client.sendMessage(targetUserId, {
            message: `✅ **AKSES DIKEMBALIKAN**\n\nFitur laporan kamu telah diaktifkan kembali. Mohon gunakan fasilitas ini dengan bijak.`,
            parseMode: "md"
          });
        } catch (err) {}
        return;
      }
    }

    if (data === "check_join") {
      const joined = await isJoinedChannel(userId);

      if (!joined) {
        return event.answer({
          message: "❌ Kamu belum join semua channel!",
          alert: true,
        });
      }

      await event.answer({ message: "✅ Verifikasi berhasil!" });

      let firstName = "User";
      try {
        const entity = await client.getEntity(userId);
        firstName = entity?.firstName || "User";
      } catch (_) {}

      return handleStart(
        {
          chatId,
          message: {
            getSender: async () => ({
              id: userId,
              firstName,
              username: null,
            }),
          },
        },
        msgId
      );
    }

    await event.answer();

    if (data === "start") {
      return await handleStart(
        {
          chatId,
          message: {
            getSender: async () => {
              try {
                const entity = await client.getEntity(userId);
                return {
                  id: userId,
                  firstName: entity?.firstName || "User",
                  username: entity?.username || null,
                };
              } catch (_) {
                return { id: userId, firstName: "User" };
              }
            },
          },
        },
        msgId
      );
    }

    if (data === "build") return await handleBuild(chatId, userId, null, msgId);
    if (data === "build_debug") return await handleBuild(chatId, userId, "debug", msgId);
    if (data === "build_release") return await handleBuild(chatId, userId, "release", msgId);
    if (data === "web2apk") return await handleWeb2Apk(chatId, userId, msgId);
    if (data === "queue") return await handleQueue(chatId, msgId);
    if (data === "help") return await handleHelp(chatId, msgId);
    if (data === "pemberitahuan") return await handleharga(chatId, msgId);
    if (data === "status") return await handleStatus(chatId, userId, msgId);

    if (data === "cancel") {
      removeUserJob(userId);
      userStates.delete(userId);
      return await send(
        chatId,
        `✅ **Dibatalkan.**\n\n` +
        `__Ketik /start atau klik tombol di bawah untuk kembali ke menu utama.__`,
        [[{ text: "🏠 Menu Utama", data: "start" }]],
        msgId
      );
    }
  } catch (err) {
    console.error("handleCallback error:", err);
  }
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
async function main() {
  console.log(`🚀 Starting ${CONFIG.BOT_NAME}...`);

  if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
  
  await askGitHubSetup();

  await client.start({
    botAuthToken: CONFIG.BOT_TOKEN,
    onError: (err) => console.error("Client error:", err),
  });

  fs.writeFileSync(SESSION_FILE, client.session.save());
  console.log("✅ Bot connected & session saved!");

  client.addEventHandler(async (event) => {
    try {
      const msg = event.message;
      const text = msg?.text?.trim();
      const chatId = event.chatId;
      const userId = Number(msg.senderId);

      if (text === "/start") return handleStart(event);
      if (text === "/build") return handleBuild(chatId);
      if (text === "/web2apk") return handleWeb2Apk(chatId);
      if (text === "/help") return handleHelp(chatId);
      if (text === "/pemberitahuan") return handleharga(chatId);      
      
      if (text?.startsWith("/broadcast") && isAdmin(userId)) {
        const replied = await event.message.getReplyMessage();
        if (!replied) return send(chatId, `⚠️ Reply pesan yang ingin di-broadcast!`);

        await send(chatId, `🚀 **Broadcast dimulai...**`);

        const users = db.getAllUsers();
        let success = 0, failed = 0;

        for (const user of users) {
          try {
            if (replied.media) {
              await client.forwardMessages(user.userId, {
                messages: [replied.id],
                fromPeer: replied.chatId,
              });
            } else {
              await send(user.userId, replied.text || replied.caption || "");
            }
            success++;
            await sleep(500);
          } catch (_) {
            failed++;
          }
        }

        return send(
          chatId,
          `✅ **Broadcast Selesai!**\n\n` +
          `✔️ **Sukses :** ${success}\n` +
          `❌ **Gagal  :** ${failed}`
        );
      }

      if (text?.startsWith("/forward") && isAdmin(userId)) {
        const replied = await event.message.getReplyMessage();
        if (!replied) return send(chatId, `⚠️ Reply pesan yang ingin di-forward!`);

        await send(chatId, `🚀 **Forward dimulai...**`);

        const users = db.getAllUsers();
        let success = 0, failed = 0;

        for (const user of users) {
          try {
            await client.forwardMessages(user.userId, {
              messages: [replied.id],
              fromPeer: replied.chatId,
            });
            success++;
            await sleep(300);
          } catch (_) {
            failed++;
          }
        }

        return send(
          chatId,
          `✅ **Forward Selesai!**\n\n` +
          `✔️ **Sukses :** ${success}\n` +
          `❌ **Gagal  :** ${failed}`
        );
      }
      
// awal tempat tools

// akhir tempat tools

      const isReportIntercepted = await handleUserReportMessages(event);
      if (isReportIntercepted) return;

      const job = getUserJob(userId);
      if (job?.type === "web2apk") {
        if (job.status === "waiting_url" && text?.startsWith("http"))
          return handleWeb2ApkUrl(event);
        if (job.status === "waiting_appname" && text)
          return handleWeb2ApkName(event);
        if (job.status === "waiting_icon" && msg.media)
          return handleWeb2ApkIcon(event);
      }

      if (msg.media) await handleZipFile(event);
    } catch (err) {
      console.error("Handler error:", err);
    }
  }, new NewMessage({}));

  client.addEventHandler(async (event) => {
    try {
      await handleCallback(event);
    } catch (err) {
      console.error("Callback error:", err);
    }
  }, new CallbackQuery({}));

  console.log(`🤖 ${CONFIG.BOT_NAME} v${CONFIG.BOT_VERSION} siap!`);
  await new Promise(() => {});
}

main().catch(console.error);